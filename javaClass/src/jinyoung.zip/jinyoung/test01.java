package jinyoung;

import java.util.Scanner;

public class test01 {

	public static void main(String[] args) {
		int n;
		int answer = 0;
		String s = Integer.toString(n); 

		for (int i = 0; i < s.length(); i++) {
			answer += Integer.parseInt(s.substring(i, i + 1));
		}
		return;
	}

}
