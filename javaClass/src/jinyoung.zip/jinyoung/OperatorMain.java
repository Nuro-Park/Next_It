package jinyoung;

public class OperatorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number = 10;
		
		//증감 연산자
		
		number++; //1 증가
		System.out.println(number);
		number--; //1감소
		System.out.println(number);
		
		++number;
		System.out.println(number);
		
		//앞, 뒤에 따라 실행 순서가 라드
		System.out.println(number++);
		System.out.println(number);	
		System.out.println(++number);
		
		System.out.println("\n==================================\n");
		
		number = 10;
		
		number += 1;
		System.out.println(number); //11
		
		number +=34;
		System.out.println(number); //45
		
		number -=20;
		System.out.println(number); //25
		
		number *= 3;
		System.out.println(number); //75
		
		number /= 5;
		System.out.println(number); //15
		
		//나누기의 몫이 되버린다.
		number /=2;
		System.out.println(number); //7
		
		//나누기의 나머지가 돼 버린다.
		number %= 3;
		System.out.println(number); //1
		
		System.out.println("\n ==================================\n");
		
		int numA = 10;
		int numB = 3;
		numA = numA + 1;
		System.out.println(numA);
		
		System.out.println("numA:11, numB : 3");
		System.out.println("더하기: "  + (numA + numB));
		System.out.println("빼기: "  + (numA - numB));
		System.out.println("곱하기: "  + (numA * numB));
		System.out.println("나누기: "  + (numA / numB));
		System.out.println("나머지: "  + (numA % numB));
		
		//먼저 계산할 부분에 대해 괄호 필수!!
		int temp = 1 + 2 * 3;
		System.out.println(temp);
	}

}
