package jinyoung.submit10;

import java.util.Scanner;

public class Submit10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Library library = Library.getInstance();
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("행동을 선택해주세요");
			System.out.println("1. 책 입고 | 2. 책 대여 | 3.책 목록 | 4. 책 검색 | 5. 종료");
			System.out.print(">>>");
			
			int select = Integer.parseInt(sc.nextLine());
			
			if(select == 1) {
				//책 입고
				System.out.println("책 번호를 입력해주세요");
				
				int no = Integer.parseInt(sc.nextLine());
				
				library.inputLib(no);
				
			}else if(select == 2) {
				//책 대여
				System.out.println("책 번호를 입력해주세요");
				System.out.print(">>>");
				
				int no = Integer.parseInt(sc.nextLine());
				
				library.selectLibrary(no);
				
			}else if(select == 3) {
				//책 목록 
				library.showLibList();
				
			}else if(select == 4) {
				//책 검색
				System.out.println("책 이름을 입력해주세요");
				
				String name = sc.nextLine();
				
				library.findBook(name);
				
			}else{
				//종료
				System.out.println("종료합니다");
				break;
			}
			
		}
		
	}

}
