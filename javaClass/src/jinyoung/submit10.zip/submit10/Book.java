package jinyoung.submit10;

public class Book {
	private int bookNo;
	private String bookName;
	private boolean bookRental;
	
	public Book() {}

	public Book(int bookNo, String bookName, boolean bookRental) {
		super();
		this.bookNo = bookNo;
		this.bookName = bookName;
		this.bookRental = bookRental;
	}

	@Override
	public String toString() {
	
		return "[책번호: " + bookNo + ", 책 제목: " + bookName + ", 대여상태: " + bookRental + "]";
	}

	public int getBookNo() {
		return bookNo;
	}

	public void setBookNo(int bookNo) {
		this.bookNo = bookNo;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public boolean isBookRental() {
		return bookRental;
	}

	public void setBookRental(boolean bookRental) {
		this.bookRental = bookRental;
	}
	
	
	
	
}
