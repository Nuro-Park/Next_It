package ch10_extends_interface.mysort;

public interface MyComparator<T> {
	public boolean myCompare(T a, T b);
}
