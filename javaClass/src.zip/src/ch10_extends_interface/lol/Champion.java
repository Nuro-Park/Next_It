package ch10_extends_interface.lol;

public class Champion {
	String name;
	int damage;
	int hp;
	
	public Champion() {
		
	}
	
	public Champion(String name, int damage, int hp) {
		super();
		this.name = name;
		this.damage = damage;
		this.hp = hp;
	}
	
	//모든 챔피언들은 스킬을 4개씩 가지고 있다.
	//Q, W, E, R
	
}
