package ch10_extends_interface.lol;

public class Amumu extends Champion implements SkillInterface{

	@Override
	public void skillQ() {
		
	}

	@Override
	public void skillW() {
		
	}

	@Override
	public void skillE() {
		
	}

	@Override
	public void skillR() {
		
	}
	
}
