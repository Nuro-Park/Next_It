package ch02_Variable;

public class VariableType {
	//변수의 타입 (기본 타입)
	
	//정수 타입
	byte byteVar = 1;
	short shortVar = 2;
	int intVar = 3;
	long longVar = 40000000000L;
	long longVar2 = 4L;
	
	//정수이면서 문자에 해당
	char charVar = 44032; //가
	char ga = '가'; //44032와 같다.
	
	//소수 타입
	double doubleVar = 0.01;
	float floatVar = 3.14f;
	
	//불리언 타입(참/거짓 , ture/false)
	boolean boolvar = false;
	
	
	
}
