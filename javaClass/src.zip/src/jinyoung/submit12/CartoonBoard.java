package jinyoung.submit12;

public class CartoonBoard extends Board {
	private String img;

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public CartoonBoard(String img) {
		super();
		this.img = img;
	}

	public CartoonBoard() {
		
	}
	
	
	
}
