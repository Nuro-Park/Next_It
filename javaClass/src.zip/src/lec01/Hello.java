package lec01;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//실행 단축키 [Ctrl + F11]
		System.out.println("Hello World");
		
		//코드라인 복사 (copy Lines)
		//단축키 [Ctrl + Alt + 방향키 아래]
		System.out.println("Hello World");
		
		//코드라인 삭제 (Delete Line)
		//단축키 [Ctrl+ D )
		System.out.println("Hello World");
		
		// 실행 취소의 취소 (Redo)
		//단축키 [Ctrl + Y]
		System.out.println("Hello World");
	
	
	}

}
